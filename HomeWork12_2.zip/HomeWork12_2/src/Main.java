import java.util.Arrays;
import java.util.Random;

//Создайте случайно заполненный числовой массив, выведите его в консоль.
// Найдите максимальное по модулю число в массиве и выведите его в консоль.
public class Main {
    public static void main(String[] args) {
        int[] array = new int[15];
        Random rnd = new Random();
        System.out.println("Массив : ");
        for (int i = 0; i < array.length; i++) {
            array[i] = rnd.nextInt(-5, 35);
            System.out.print(array[i] + " ");
        }
        int maxValue = Math.abs(array[0]);
        for (int i = 1; i < array.length; i++) {
            if (Math.abs(array[i]) > maxValue) {
                maxValue = Math.abs(array[i]);
            }
        }
        System.out.println();
        System.out.println("Максимальное число по модулю в массиве = " + maxValue);
        System.out.println(Arrays.toString(array));
    }
}