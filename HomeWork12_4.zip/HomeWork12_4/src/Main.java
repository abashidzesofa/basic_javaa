import java.util.Scanner;

//ользователь вводит строку.
// Посчитайте количество слов в строке и выведите в консоль.
// Разделителем между словами считать только пробел.
// Если в строке есть слова, которые длиннее трёх символов,
// то вывести эти слова в консоль.
public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Пожалуйста, введите строку : ");
        String userStr = scn.nextLine();
        String[] strArr = userStr.split(" ");
        int wordCount = strArr.length;
        System.out.println("Количество слов в строке : " + wordCount);
        System.out.println("Слова, содержащие больше трех символов : ");
        for (String word : strArr) {
            if (word.length() > 3) {
                System.out.println(word + " ");
            }
        }
    }
}
