//1 n - номер дома, в котором Вы живёте (без учёта дробей, корпусов, строений и т.д).
// Создайте массив целых чисел.
// Заполните массив числами от 0 до n*10, выведите массив в консоль.
public class Main {
    public static void main(String[] args) {
        int n = 3;
        int[] array = new int[(n +1) * 10];
        for (int i = 0; i < array.length; i++){
            array[i] = i;
            System.out.print(array[i] + " ");
        }

    }
}