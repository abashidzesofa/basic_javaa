import java.util.Arrays;
import java.util.Scanner;

//Пользователь вводит строку.
// Разместите буквы в строке по алфавиту и выведите в консоль.
public class Main {
    public static void main(String[] args) {
        System.out.println("Пожалуйста, введите строку : ");
        Scanner scn = new Scanner(System.in);
        String userStr = scn.nextLine();
        char[]charArray = userStr.toCharArray();
        Arrays.sort(charArray);
        System.out.println(charArray);
    }
}